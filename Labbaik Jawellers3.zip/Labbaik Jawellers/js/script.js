

    function loadSection(section_name){  
    
        //loAD ext file
    
        let xhr = new XMLHttpRequest();
    
        let url = "./" + section_name  + ".html"; 
        // request setting 
        xhr.open("GET", url, true);
       
        // after request data
        xhr.onload = function(){
            let section = document.getElementById(section_name);
            section.innerHTML = xhr.responseText;
        }
    
        //
        xhr.send();
    }
    
    function loadAllSections(){
        loadSection("navbar2");
        loadSection("category");
        loadSection("footer")   
        loadSection("feature_brand");
        loadSection("our_promise");
        loadSection("about_us");
        loadSection("welcome");
    }

    window.addEventListener("load", loadAllSections)
